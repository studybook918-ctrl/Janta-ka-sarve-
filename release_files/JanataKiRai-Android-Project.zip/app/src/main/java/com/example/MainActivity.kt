package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.auth.AuthManager
import com.example.data.repository.SurveyRepository
import com.example.ui.ScreenState
import com.example.ui.SurveyViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.EvmScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.theme.JanataKiRaiTheme
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {

  private val authManager by lazy { AuthManager() }

  private val surveyViewModel by viewModels<SurveyViewModel> {
    object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val databaseId = getString(R.string.firestore_database_id)
        val firestore = FirebaseFirestore.getInstance(databaseId)
        val repository = SurveyRepository(firestore)
        return SurveyViewModel(repository) as T
      }
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      com.google.firebase.FirebaseApp.initializeApp(applicationContext)
    } catch (_: Exception) {}
    enableEdgeToEdge()
    setContent {
      JanataKiRaiTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          SurveyAppContent(
            viewModel = surveyViewModel,
            authManager = authManager
          )
        }
      }
    }
  }
}

@Composable
fun SurveyAppContent(
  viewModel: SurveyViewModel,
  authManager: AuthManager
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsState()

  when (uiState.currentScreen) {
    ScreenState.HOME -> {
      HomeScreen(
        districts = uiState.districts,
        selectedDistrict = uiState.selectedDistrict,
        selectedConstituency = uiState.selectedConstituency,
        availableConstituencies = uiState.availableConstituencies,
        onDistrictSelected = { viewModel.selectDistrict(it) },
        onConstituencySelected = { viewModel.selectConstituency(it) },
        onProceedToEvm = { viewModel.proceedToEvm() }
      )
    }

    ScreenState.EVM -> {
      val district = uiState.selectedDistrict
      val constituency = uiState.selectedConstituency
      if (district != null && constituency != null) {
        EvmScreen(
          district = district,
          constituency = constituency,
          candidates = uiState.candidates,
          onBackToHome = { viewModel.backToHome() },
          onProceedWithCandidate = { candidate ->
            viewModel.proceedWithCandidate(candidate, authManager)
          }
        )
      } else {
        viewModel.backToHome()
      }
    }

    ScreenState.AUTH -> {
      val constituency = uiState.selectedConstituency
      if (constituency != null) {
        AuthScreen(
          candidate = uiState.selectedCandidate,
          constituency = constituency,
          isLoading = uiState.isLoading,
          errorMessage = uiState.errorMessage,
          voteSuccess = uiState.voteSuccess,
          alreadyVoted = uiState.alreadyVoted,
          onSignInClick = { viewModel.signInWithGoogle(context, authManager) },
          onViewResultsClick = { viewModel.viewResults(authManager) },
          onBackToEvm = { viewModel.backToEvm() }
        )
      } else {
        viewModel.backToHome()
      }
    }

    ScreenState.RESULTS -> {
      val district = uiState.selectedDistrict
      val constituency = uiState.selectedConstituency
      if (district != null && constituency != null) {
        ResultsScreen(
          district = district,
          constituency = constituency,
          survey = uiState.currentSurvey,
          candidates = uiState.candidates,
          onRefresh = { viewModel.refreshResults() },
          onBackToHome = { viewModel.backToHome() }
        )
      } else {
        viewModel.backToHome()
      }
    }
  }
}
