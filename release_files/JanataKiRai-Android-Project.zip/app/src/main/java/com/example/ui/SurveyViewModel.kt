package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.AuthManager
import com.example.data.model.Candidate
import com.example.data.model.Constituency
import com.example.data.model.District
import com.example.data.model.Survey
import com.example.data.repository.SurveyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenState {
  HOME,
  EVM,
  AUTH,
  RESULTS
}

data class SurveyUiState(
  val currentScreen: ScreenState = ScreenState.HOME,
  val districts: List<District> = emptyList(),
  val selectedDistrict: District? = null,
  val availableConstituencies: List<Constituency> = emptyList(),
  val selectedConstituency: Constituency? = null,
  val candidates: List<Candidate> = emptyList(),
  val selectedCandidate: Candidate? = null,
  val currentSurvey: Survey = Survey(),
  val isLoading: Boolean = false,
  val errorMessage: String? = null,
  val voteSuccess: Boolean = false,
  val alreadyVoted: Boolean = false
)

class SurveyViewModel(
  private val repository: SurveyRepository
) : ViewModel() {

  private val _uiState = MutableStateFlow(SurveyUiState())
  val uiState: StateFlow<SurveyUiState> = _uiState.asStateFlow()

  init {
    val districts = repository.getDistricts()
    _uiState.update { it.copy(districts = districts) }
  }

  fun selectDistrict(district: District) {
    val constituencies = repository.getConstituencies(district.districtId)
    _uiState.update {
      it.copy(
        selectedDistrict = district,
        availableConstituencies = constituencies,
        selectedConstituency = null,
        candidates = emptyList(),
        selectedCandidate = null
      )
    }
  }

  fun selectConstituency(constituency: Constituency) {
    val candidates = repository.getCandidates(constituency)
    _uiState.update {
      it.copy(
        selectedConstituency = constituency,
        candidates = candidates,
        selectedCandidate = null
      )
    }
  }

  fun proceedToEvm() {
    val constituency = _uiState.value.selectedConstituency ?: return
    viewModelScope.launch {
      val survey = repository.getSurvey(constituency.constituencyId)
      _uiState.update {
        it.copy(
          currentScreen = ScreenState.EVM,
          currentSurvey = survey,
          errorMessage = null
        )
      }
    }
  }

  fun proceedWithCandidate(candidate: Candidate, authManager: AuthManager) {
    _uiState.update {
      it.copy(
        selectedCandidate = candidate,
        currentScreen = ScreenState.AUTH,
        voteSuccess = false,
        alreadyVoted = false,
        errorMessage = null
      )
    }

    // If user is already authenticated, check if they voted or submit vote
    val user = authManager.currentUser
    if (user != null) {
      checkAndSubmitVote(user.uid)
    }
  }

  fun signInWithGoogle(context: Context, authManager: AuthManager) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, errorMessage = null) }
      val result = authManager.signInWithGoogle(context)
      result.fold(
        onSuccess = { user ->
          _uiState.update { it.copy(isLoading = false) }
          checkAndSubmitVote(user.uid)
        },
        onFailure = { error ->
          val friendlyMsg = when {
            error is androidx.credentials.exceptions.GetCredentialCancellationException ->
              "लॉगिन प्रक्रिया रद्द की गई। जारी रखने के लिए Google खाता चुनें।"
            error.message?.contains("network", ignoreCase = true) == true ->
              "इंटरनेट कनेक्शन जाँचें और पुनः प्रयास करें।"
            else ->
              error.localizedMessage ?: "लॉगिन विफल रहा। कृपया पुनः प्रयास करें।"
          }
          _uiState.update {
            it.copy(
              isLoading = false,
              errorMessage = friendlyMsg
            )
          }
        }
      )
    }
  }

  private fun checkAndSubmitVote(userId: String) {
    val constituency = _uiState.value.selectedConstituency ?: return
    val candidate = _uiState.value.selectedCandidate
    val surveyId = "survey_${constituency.constituencyId}"

    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true) }
      val existingVote = repository.getUserResponse(surveyId, userId)
      if (existingVote != null) {
        // User has already cast a vote
        val updatedSurvey = repository.getSurvey(constituency.constituencyId)
        _uiState.update {
          it.copy(
            isLoading = false,
            alreadyVoted = true,
            currentSurvey = updatedSurvey
          )
        }
      } else if (candidate != null) {
        // Submit the vote
        val submitResult = repository.submitVote(
          surveyId = surveyId,
          constituencyId = constituency.constituencyId,
          candidateId = candidate.candidateId,
          userId = userId
        )
        submitResult.fold(
          onSuccess = {
            val updatedSurvey = repository.getSurvey(constituency.constituencyId)
            _uiState.update {
              it.copy(
                isLoading = false,
                voteSuccess = true,
                currentSurvey = updatedSurvey
              )
            }
          },
          onFailure = { err ->
            _uiState.update {
              it.copy(
                isLoading = false,
                errorMessage = err.localizedMessage ?: "आपकी राय दर्ज नहीं हो सकी।"
              )
            }
          }
        )
      } else {
        _uiState.update { it.copy(isLoading = false) }
      }
    }
  }

  fun viewResults(authManager: AuthManager) {
    val constituency = _uiState.value.selectedConstituency ?: return
    val user = authManager.currentUser
    if (user == null) {
      // Must be logged in to view results per PRD
      _uiState.update {
        it.copy(
          currentScreen = ScreenState.AUTH,
          errorMessage = "परिणाम देखने के लिए लॉगिन अनिवार्य है।"
        )
      }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true) }
      val survey = repository.getSurvey(constituency.constituencyId)
      _uiState.update {
        it.copy(
          isLoading = false,
          currentScreen = ScreenState.RESULTS,
          currentSurvey = survey
        )
      }
    }
  }

  fun refreshResults() {
    val constituency = _uiState.value.selectedConstituency ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true) }
      val survey = repository.getSurvey(constituency.constituencyId)
      _uiState.update {
        it.copy(
          isLoading = false,
          currentSurvey = survey
        )
      }
    }
  }

  fun backToHome() {
    _uiState.update {
      it.copy(
        currentScreen = ScreenState.HOME,
        selectedCandidate = null,
        voteSuccess = false,
        alreadyVoted = false,
        errorMessage = null
      )
    }
  }

  fun backToEvm() {
    _uiState.update {
      it.copy(
        currentScreen = ScreenState.EVM,
        voteSuccess = false,
        alreadyVoted = false,
        errorMessage = null
      )
    }
  }
}
