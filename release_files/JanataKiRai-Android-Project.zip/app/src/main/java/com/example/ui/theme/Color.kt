package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1E3A8A)
val NavyDark = Color(0xFF0F172A)
val GreenSuccess = Color(0xFF10B981)
val GreenDark = Color(0xFF047857)
val EvmBlue = Color(0xFF2563EB)
val EvmBlueDark = Color(0xFF1D4ED8)
val EvmLightBlue = Color(0xFFE0F2FE)
val EvmUnitCase = Color(0xFFE2E8F0)
val EvmPaper = Color(0xFFFFFDF5)
val EvmRedLed = Color(0xFFEF4444)
val EvmRedLedOff = Color(0xFF4B1818)
val SurfaceLight = Color(0xFFF8FAFC)
val CardBorder = Color(0xFFCBD5E1)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF475569)
