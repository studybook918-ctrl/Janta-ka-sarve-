package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
  primary = NavyPrimary,
  onPrimary = Color.White,
  primaryContainer = EvmLightBlue,
  onPrimaryContainer = NavyDark,
  secondary = GreenSuccess,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFD1FAE5),
  onSecondaryContainer = GreenDark,
  tertiary = EvmBlue,
  onTertiary = Color.White,
  background = SurfaceLight,
  onBackground = TextDark,
  surface = Color.White,
  onSurface = TextDark,
  surfaceVariant = EvmUnitCase,
  onSurfaceVariant = TextMuted,
  outline = CardBorder
)

private val DarkColorScheme = darkColorScheme(
  primary = Color(0xFF93C5FD),
  onPrimary = NavyDark,
  primaryContainer = NavyPrimary,
  onPrimaryContainer = Color.White,
  secondary = Color(0xFF6EE7B7),
  onSecondary = GreenDark,
  tertiary = Color(0xFF60A5FA),
  background = Color(0xFF0F172A),
  onBackground = Color(0xFFF8FAFC),
  surface = Color(0xFF1E293B),
  onSurface = Color(0xFFF8FAFC),
  surfaceVariant = Color(0xFF334155),
  onSurfaceVariant = Color(0xFF94A3B8),
  outline = Color(0xFF475569)
)

@Composable
fun JanataKiRaiTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
